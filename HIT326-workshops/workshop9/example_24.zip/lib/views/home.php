<h1>Home page</h1>

<p><?php echo $message ?></p>
