 <label for='password-confirm'>Confirm password</label>
 <input type='password' id='password-confirm' name='password-confirm' />
 

