use players_db;

INSERT INTO players (fname,sname) values ("Jon","Smith");
INSERT INTO players (fname,sname,games) values ("Fred","Nerk",2);
INSERT INTO players (fname,sname,games) values ("Joanne","Cleverley",8);

