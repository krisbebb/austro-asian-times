 <label for='name'>Name</label>
 <input type='text' id='name' name='name' />


