#Usage
#prompt> mysql < test.sql -u root -p
# OR
#prompt> mysql < test.sql -u root -phit325

use friendships_db;

SELECT * FROM users;
SELECT * FROM friends;