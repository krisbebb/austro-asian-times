
</br>

<label for='tags'>Select one or more tags: </label>
<!-- <input type='text' id='data' name='data'/> -->
</br>
<input type='checkbox' id='tags' name='tags[]' value = "1"/> Australia </br>


<input type='checkbox' id='tags' name='tags[]' value = "2"/> World </br>
</label>
<input type='checkbox' id='tags' name='tags[]' value = "3"/> Technology </br>
<input type='checkbox' id='tags' name='tags[]' value = "4"/> Sport </br>
<input type='checkbox' id='tags' name='tags[]' value = "5" checked/> General </br>
