<label for='firstname'>First Name</label>
<input type='text' id='firstname' name='firstname'/>
